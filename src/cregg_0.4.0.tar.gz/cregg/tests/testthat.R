library("testthat")
library("cregg")

test_check("cregg")
